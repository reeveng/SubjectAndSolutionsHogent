package domein;

public class VeggiePizza extends Pizza {

}
