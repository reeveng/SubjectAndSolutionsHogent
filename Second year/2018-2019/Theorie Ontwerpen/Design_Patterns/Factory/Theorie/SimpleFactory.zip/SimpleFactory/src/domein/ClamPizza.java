package domein;

public class ClamPizza extends Pizza {

}
