package domein;

public class CheesePizza extends Pizza {

}
