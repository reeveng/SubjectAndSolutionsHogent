package domein;

public class PepperoniPizza extends Pizza {

}
