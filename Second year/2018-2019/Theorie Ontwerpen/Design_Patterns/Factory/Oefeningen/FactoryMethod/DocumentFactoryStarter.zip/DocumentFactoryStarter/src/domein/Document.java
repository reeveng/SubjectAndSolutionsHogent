package domein;

//PRODUCT
public interface Document {

}
