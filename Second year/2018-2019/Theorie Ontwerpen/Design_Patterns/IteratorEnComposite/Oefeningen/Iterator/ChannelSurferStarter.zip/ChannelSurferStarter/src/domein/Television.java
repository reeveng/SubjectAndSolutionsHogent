package domein;

public class Television {

    //TODO attributes


    public Television(int maxChannel) {
        //TODO
    }

    public Program getNextProgram() {
        //TODO
        return null;
    }

    public Program getPrevProgram() {
        //TODO
        return null;
    }

}
