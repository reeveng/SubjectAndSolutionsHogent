package domein;

import java.util.ArrayList;
import java.util.List;

public class Diagram  {
//TODO
}
