package oefeningcomposite;

import domein.*;

public class OefeningComposite {
    public static void main(String[] args) {
        new OefeningComposite();
    }
    public OefeningComposite() {
//Uncomment
//        Graphic allGraphics = new Diagram();
//        allGraphics.add(new Line(1, 2, 6, 6));
//        Graphic subGraphics1 = new Diagram();
//        subGraphics1.add(new Rectangle(5, 6, 20, 30));
//        subGraphics1.add(new Text(2, 3, "een beetje tekst"));
//        Graphic subGraphics2 = new Diagram();
//        subGraphics2.add(new Line(4, 3, 5, 5));
//        subGraphics2.add(new Text(5, 6, "een vervolg"));
//        subGraphics1.add(subGraphics2);
//        allGraphics.add(subGraphics1);
//        allGraphics.add(new Line(1, 3, 9, 9));
//        allGraphics.draw();
    }

}
