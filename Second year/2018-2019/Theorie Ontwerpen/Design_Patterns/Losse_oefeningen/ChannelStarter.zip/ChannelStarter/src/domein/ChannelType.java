package domein;

public enum ChannelType {

    ENGLISH, HINDI, FRENCH, ALL;
}
