package domein;

import javax.swing.JOptionPane;

public class ApplicatieFout {

    public ApplicatieFout(String foutboodschap) {
        JOptionPane.showMessageDialog(null, foutboodschap);
    }

}
