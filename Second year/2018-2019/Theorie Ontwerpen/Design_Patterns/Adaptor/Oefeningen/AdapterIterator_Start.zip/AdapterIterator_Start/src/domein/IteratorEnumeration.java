package domein;

import java.util.Enumeration;
import java.util.Iterator;


public class IteratorEnumeration {

    
   
}
