package swingComponenten;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

public class ImageIconUitSwing implements Icon {

    @Override
    public int getIconWidth() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getIconHeight() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void paintIcon(final Component c, Graphics g, int x, int y) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}