package domein;

import java.lang.reflect.*;

public class NonOwnerInvocationHandler  {


    
    
    
    
}


