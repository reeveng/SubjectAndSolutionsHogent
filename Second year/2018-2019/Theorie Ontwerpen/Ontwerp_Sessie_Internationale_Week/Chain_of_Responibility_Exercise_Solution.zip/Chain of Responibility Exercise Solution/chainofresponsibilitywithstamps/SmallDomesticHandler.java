package chainofresponsibilitywithstamps;

public class SmallDomesticHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {

		if (o.isDomesticAdress()) {
			if (o.getWeight() <= 2 && o.getLength() <= 30 && o.getWidth() <= 30  && o.getHeight() <= 15) {
				o.shippingRate = 4.25f;
				System.out.println( o + "\t\thandled by " + this);
			}
		}

		if (nextHandler != null)
			nextHandler.processOrder(o);
		
	}

	@Override
	public String toString() {
		return "SmallDomesticHandler";
	};
}
 
