package chainofresponsibilitywithstamps;

public class ShippingHandler {

	public static void main(String[] args) {

		// create different shipment handlers
		OrderHandler handler1 = new SmallDomesticHandler();
		OrderHandler handler2 = new LargeDomesticHandler();
		OrderHandler handler3 = new EuropeanUnionHandler();
		OrderHandler handler4 = new InternationalHandler();

		// setup the ShippingChain
		handler1.setNextOrderHandler(handler2);
		handler2.setNextOrderHandler(handler3);
		handler3.setNextOrderHandler(handler4);

		// setup the StampChain
		OrderHandler handler5 = new OneEuroStampHandler();
		OrderHandler handler6 = new FiftyCentStampHandler();
		OrderHandler handler7 = new TwentyFiveCentStampHandler();
		
		handler4.setNextOrderHandler(handler5);
		handler5.setNextOrderHandler(handler6);
		handler6.setNextOrderHandler(handler7);

		// process different requests
		handler1.processOrder(new Order(1.5f, 15, 25, 10, Order.Adress.DOMESTIC));
		handler1.processOrder(new Order(35, 76, 50, 70, Order.Adress.INTERNATIONAL));
		handler1.processOrder(new Order(4.5f, 48, 19, 9, Order.Adress.DOMESTIC));

		handler1.processOrder(new Order(9.5f, 80, 50, 100, Order.Adress.EUROPEAN_UNION));
		handler1.processOrder(new Order(3.5f, 17, 30, 15, Order.Adress.DOMESTIC));

	}

}
