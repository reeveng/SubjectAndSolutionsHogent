package chainofresponsibilitywithstamps;

public class InternationalHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {

		if (o.isInternationalAdress()) {
			if (o.getWeight() <= 70 && o.getLength() <= 150 && o.getWidth() <= 60 && o.getHeight() <= 70) {
				o.shippingRate = 30;
				System.out.println(o + "\thandled by " + this);
			}
		}

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

	@Override
	public String toString() {
		return "InternationalHandler";
	};

}
