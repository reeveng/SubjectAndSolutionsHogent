package chainofresponsibilitywithstamps;

public class EuropeanUnionHandler extends OrderHandler {
	
	@Override
	public void processOrder(Order o) {

		if (o.isEuropeanUnionAdress())
			if (o.getWeight() <= 10 && o.getLength() <= 80 && o.getWidth() <= 60 && o.getHeight() <= 100) {
				o.shippingRate = 10.5f;
				System.out.println(o + "\thandled by " + this);
			}

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

	@Override
	public String toString() {
		return "EuropeanUnionHandler";
	};

}
