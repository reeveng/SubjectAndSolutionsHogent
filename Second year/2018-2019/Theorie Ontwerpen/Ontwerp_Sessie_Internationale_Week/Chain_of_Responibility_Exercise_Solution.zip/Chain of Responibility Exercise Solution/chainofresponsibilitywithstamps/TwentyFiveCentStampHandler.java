package chainofresponsibilitywithstamps;

public class TwentyFiveCentStampHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {
		int rate = (int) (o.shippingRate * 100);
		int nb = rate / 25;

		o.shippingRate -= nb * 0.25;
		System.out.println("stamped with " + nb + " x 0,25 �");

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

}
