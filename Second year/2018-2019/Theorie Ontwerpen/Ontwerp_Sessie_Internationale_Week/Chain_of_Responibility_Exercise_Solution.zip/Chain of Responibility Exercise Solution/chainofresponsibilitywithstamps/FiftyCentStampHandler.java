package chainofresponsibilitywithstamps;

public class FiftyCentStampHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {
		int rate = (int) (o.shippingRate * 100);
		int nb = rate / 50;

		o.shippingRate -= nb * 0.5;
		System.out.println("stamped with " + nb + " x 0,5 �");

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

}
