package chainofresponsibilitywithstamps;

public class OneEuroStampHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {
		int rate = (int) (o.shippingRate * 100);
		int nb = rate / 100;

		o.shippingRate -= nb * 1;
		System.out.println("stamped with " + nb + " x 1 �");

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

}
