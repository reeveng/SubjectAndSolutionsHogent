package chainofresponsibilitywithstamps;

public class Order {

	private float weight;
	private int height, width, length;
	Adress adress;
	float shippingRate;

	public enum Adress {
		DOMESTIC, EUROPEAN_UNION, INTERNATIONAL
	};

	public Order(float weight, int length, int width, int height, Adress adress) {
		super();

		this.weight = weight;
		this.height = height;
		this.width = width;
		this.length = length;
		this.adress = adress;
	}

	public int getLength() {
		return length;
	}

	public float getWeight() {
		return weight;
	}

	public int getHeight() {
		return height;
	}

	public int getWidth() {
		return width;
	}

	public boolean isDomesticAdress() {
		return adress.equals(Adress.DOMESTIC);
	}

	public boolean isEuropeanUnionAdress() {
		return adress.equals(Adress.EUROPEAN_UNION);
	}

	public boolean isInternationalAdress() {
		return adress.equals(Adress.INTERNATIONAL);
	}

	@Override
	public String toString() {
		return "Order [ Weight=" + weight + " kg, " + "L=" + length + " cm, W=" + width + " cm, " + "H=" + height
				+", " + adress + ", " + shippingRate + "� ] ";
	}

}
