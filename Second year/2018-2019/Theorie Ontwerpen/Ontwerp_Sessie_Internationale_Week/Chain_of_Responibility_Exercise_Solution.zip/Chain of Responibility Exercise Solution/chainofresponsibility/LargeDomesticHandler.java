package chainofresponsibility;

public class LargeDomesticHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {

		if (o.isDomesticAdress()) {
			if (o.getWeight() > 2 && o.getWeight() <= 5 && o.getLength() <= 60 && o.getWidth() <= 30 && o.getHeight() <= 15)
				System.out.println( o + "\t\thandled by " + this);
		}

		if (nextHandler != null)
			nextHandler.processOrder(o);
		
	}
	
	@Override
	public String toString() {
		return "LargeDomesticHandler";
	};

}
