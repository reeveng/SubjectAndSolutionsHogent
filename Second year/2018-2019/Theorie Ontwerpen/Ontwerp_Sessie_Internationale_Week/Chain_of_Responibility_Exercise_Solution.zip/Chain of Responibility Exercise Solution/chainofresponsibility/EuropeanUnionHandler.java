package chainofresponsibility;

public class EuropeanUnionHandler extends OrderHandler {

	@Override
	public void processOrder(Order o) {

		if (o.isEuropeanUnionAdress())
			if (o.getWeight() <= 10 && o.getLength() <= 80 && o.getWidth() <= 60 && o.getHeight() <= 100) {
				System.out.println(o + "\thandled by " + this);
			}

		if (nextHandler != null)
			nextHandler.processOrder(o);

	}

	@Override
	public String toString() {
		return "EuropeanUnionHandler";
	};

}
