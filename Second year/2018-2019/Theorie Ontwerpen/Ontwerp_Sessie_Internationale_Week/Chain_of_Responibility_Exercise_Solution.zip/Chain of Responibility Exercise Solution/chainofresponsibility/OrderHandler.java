package chainofresponsibility;

public abstract class OrderHandler {
	
	protected OrderHandler nextHandler;
	
	public abstract void processOrder(Order o);
	
	public void setNextOrderHandler(OrderHandler next) {
		if (next != null) nextHandler = next;
	}
	
	@Override
	public String toString() {
		return "" + this.getClass().getName();
	};
	
}
