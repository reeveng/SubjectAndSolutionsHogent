The following solution is a simple solution for the chain of responsibility design pattern exercise.

Each Handler class overrides the proceedOrder method and has to include 

		if (nextHandler != null)
				nextHandler.processOrder(o);
			
in order to avoid the broken chain problem.

This could be improved and refactored by applying the template method design pattern. Think about that and refactor the code.