﻿using System;
namespace RecipeApi.Models
{
    public class RatedRecipe
    {
        #region Properties

        public Recipe Name { get; set; }


        public RatedRecipe()
        {
        }
    }
}
