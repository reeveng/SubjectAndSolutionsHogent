﻿namespace BeerhallEF.Models
{
    public enum Language
    {
        Nederlands,
        Français,
        English
    }
}
