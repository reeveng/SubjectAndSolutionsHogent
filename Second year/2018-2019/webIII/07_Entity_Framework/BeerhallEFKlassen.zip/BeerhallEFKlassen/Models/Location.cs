﻿namespace BeerhallEF.Models
{
    public class Location
    {
        #region Properties
        public string PostalCode { get; set; }
        public string Name { get; set; }
        #endregion

    }
}
