﻿namespace ThePlaceToMeet.Models.Domain
{
    public class Catering
    {
        public int Id { get; set; }
        public string Titel { get; set; }
        public string Beschrijving { get; set; }
        public decimal PrijsPerPersoon { get; set; }
    }
}
