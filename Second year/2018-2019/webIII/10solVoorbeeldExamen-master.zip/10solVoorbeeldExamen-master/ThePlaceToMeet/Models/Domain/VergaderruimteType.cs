﻿namespace ThePlaceToMeet.Models.Domain
{
    public enum VergaderruimteType
    {
        Brainstorm,
        BreakOut,
        Meeting
    }
}
