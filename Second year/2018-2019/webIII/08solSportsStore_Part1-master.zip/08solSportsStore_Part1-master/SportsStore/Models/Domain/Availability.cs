﻿namespace SportsStore.Models.Domain {
    public enum Availability {
        ShopAndOnline,
        ShopOnly,
        OnlineOnly
    }
}
