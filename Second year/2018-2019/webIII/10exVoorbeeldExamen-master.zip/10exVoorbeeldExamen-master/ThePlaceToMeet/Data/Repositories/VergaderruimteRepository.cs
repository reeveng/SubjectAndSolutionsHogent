
namespace ThePlaceToMeet.Data.Repositories
{
    public class VergaderruimteRepository
    {
    }
}
