﻿namespace ThePlaceToMeet.Models.Domain
{
    public class Korting
    {
        public int Id { get; set; }
        public int Percentage { get; set; }
        public int MinimumAantalReservatiesInJaar { get; set; }
    }
}
