package domein;

public class Screen {

    public Screen() {
        //TODO
    }

    public void addButton() {
        //TODO
    }

    public void addLabel() {
        //TODO
    }

    public void viewComponents() {
        //TODO
    }
}
