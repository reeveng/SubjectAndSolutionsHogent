package domein;

public class ScreenFactory {

    public static Screen createScreen(String type) {
        switch (type.toLowerCase()) {
            case "win":
               //TODO
            case "mac":
              //TODO
        }
        return null;
    }
}
