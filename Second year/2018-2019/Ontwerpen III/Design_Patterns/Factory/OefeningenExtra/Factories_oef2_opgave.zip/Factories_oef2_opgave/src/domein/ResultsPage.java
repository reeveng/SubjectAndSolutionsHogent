package domein;

public class ResultsPage implements Page {

    @Override
    public String print() {
        return "ResultsPage";
    }

}
