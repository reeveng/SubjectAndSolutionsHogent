package domein;

public class EducationPage implements Page {

    @Override
    public String print() {
        return "EducationPage";
    }

}
