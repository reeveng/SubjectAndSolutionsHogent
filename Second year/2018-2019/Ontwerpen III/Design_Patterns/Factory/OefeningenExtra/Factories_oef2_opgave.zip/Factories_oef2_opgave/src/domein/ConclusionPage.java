package domein;

public class ConclusionPage implements Page {

    @Override
    public String print() {
        return "ConclusionPage";
    }

}
