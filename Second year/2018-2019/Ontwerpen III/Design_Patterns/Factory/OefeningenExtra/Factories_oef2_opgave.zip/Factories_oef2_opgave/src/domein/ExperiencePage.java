package domein;

public class ExperiencePage implements Page {

    @Override
    public String print() {
        return "ExperiencePage";
    }
}
