package domein;

public interface Page {

    public String print();

}
