package domein;

public class IntroductionPage implements Page {

    @Override
    public String print() {
        return "IntroductionPage";
    }

}
