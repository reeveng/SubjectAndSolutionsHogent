package domein;

public class SummaryPage implements Page {

    @Override
    public String print() {
        return "SummaryPage";
    }
}
