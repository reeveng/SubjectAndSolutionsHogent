package domein;

import java.util.stream.Collectors;
public abstract class Document 
{

    
    /*public String print() {
        return pages.stream()
                .map(Page::print)
                .collect(Collectors.joining("\n"));
    }*/
}
