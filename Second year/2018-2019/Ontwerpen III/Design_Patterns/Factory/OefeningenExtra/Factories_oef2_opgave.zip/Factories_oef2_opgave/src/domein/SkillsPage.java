package domein;

public class SkillsPage implements Page {

    @Override
    public String print() {
        return "SkillsPage";
    }

}
