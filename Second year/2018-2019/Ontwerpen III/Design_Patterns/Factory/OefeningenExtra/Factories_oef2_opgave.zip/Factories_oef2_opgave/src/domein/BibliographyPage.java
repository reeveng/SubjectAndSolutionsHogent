package domein;

public class BibliographyPage implements Page {

    @Override
    public String print() {
        return "BibliographyPage";
    }
}
