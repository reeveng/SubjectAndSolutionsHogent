package main;

public class StartUp {
//Uncomment
//	private Persistence persistence;
//	private Drawing drawing;
//	private Writer writer;
//	private Reader reader;
//	private String filePath;
	
	public static void main(String[] args) {
		new StartUp().run();
	}
	private void run() {
//Uncomment
//                                  persistence = new Persistence(new BinaryPersistenceFactory());
//		filePath = "c:/drawing.dat";
//		writer = persistence.newWriter();
//		writer.writeDrawing(filePath, drawing);
//		reader = persistence.newReader();
//		reader.readDrawing(filePath);
//		
//		persistence = new Persistence(new XMLPersistenceFactory());		
//		filePath="c:/drawing.xml";
//		writer = persistence.newWriter();
//		writer.writeDrawing(filePath, drawing);
//		reader = persistence.newReader();
//		reader.readDrawing(filePath);
		
	}
}
