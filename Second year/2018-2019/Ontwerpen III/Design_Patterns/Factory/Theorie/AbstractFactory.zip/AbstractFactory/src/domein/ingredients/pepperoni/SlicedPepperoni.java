package domein.ingredients.pepperoni;

import domein.ingredients.Pepperoni;

public class SlicedPepperoni implements Pepperoni {

    public String toString() {
        return "Sliced Pepperoni";
    }
}
