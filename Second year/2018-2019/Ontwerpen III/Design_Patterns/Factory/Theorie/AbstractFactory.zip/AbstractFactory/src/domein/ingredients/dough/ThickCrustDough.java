package domein.ingredients.dough;

import domein.ingredients.Dough;

public class ThickCrustDough implements Dough {

    public String toString() {
        return "ThickCrust style extra thick crust dough";
    }
}
