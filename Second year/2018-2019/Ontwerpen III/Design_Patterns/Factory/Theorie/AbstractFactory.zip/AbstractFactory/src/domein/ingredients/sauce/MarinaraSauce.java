package domein.ingredients.sauce;

import domein.ingredients.Sauce;

public class MarinaraSauce implements Sauce {

    public String toString() {
        return "Marinara Sauce";
    }
}
