package domein.ingredients.veggies;

import domein.ingredients.Veggies;

public class Mushroom implements Veggies {

    public String toString() {
        return "Mushrooms";
    }

}
