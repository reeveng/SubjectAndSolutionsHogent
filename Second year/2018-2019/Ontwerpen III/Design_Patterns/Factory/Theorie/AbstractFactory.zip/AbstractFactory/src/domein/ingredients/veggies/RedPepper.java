package domein.ingredients.veggies;

import domein.ingredients.Veggies;

public class RedPepper implements Veggies {

    public String toString() {
        return "Red Pepper";
    }

}
