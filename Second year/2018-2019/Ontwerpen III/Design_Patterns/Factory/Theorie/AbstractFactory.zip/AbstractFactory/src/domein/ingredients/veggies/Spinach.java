package domein.ingredients.veggies;

import domein.ingredients.Veggies;

public class Spinach implements Veggies {

    public String toString() {
        return "Spinach";
    }
}
