package domein.ingredients.clams;

import domein.ingredients.Clams;

public class FrozenClams implements Clams {

    public String toString() {
        return "Frozen Clams from Chesapeake Bay";
    }
}
