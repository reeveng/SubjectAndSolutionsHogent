package domein.ingredients.cheese;

import domein.ingredients.Cheese;
public class ReggianoCheese implements Cheese {

	public String toString() {
		return "Reggiano Cheese";
	}
}