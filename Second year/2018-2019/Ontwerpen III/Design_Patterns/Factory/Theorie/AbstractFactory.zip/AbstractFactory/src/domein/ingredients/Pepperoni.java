package domein.ingredients;

public interface Pepperoni {

    public String toString();
}
