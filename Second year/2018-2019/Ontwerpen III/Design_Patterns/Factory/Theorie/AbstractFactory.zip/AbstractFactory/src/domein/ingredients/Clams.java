package domein.ingredients;

public interface Clams {

    public String toString();
}
