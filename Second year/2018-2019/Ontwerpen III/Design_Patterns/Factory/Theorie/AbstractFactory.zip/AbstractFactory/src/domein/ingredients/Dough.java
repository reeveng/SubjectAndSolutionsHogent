package domein.ingredients;

public interface Dough {

    public String toString();
}
