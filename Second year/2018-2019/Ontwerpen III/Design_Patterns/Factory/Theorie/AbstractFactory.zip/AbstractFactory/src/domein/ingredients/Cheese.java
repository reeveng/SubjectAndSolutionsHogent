package domein.ingredients;

public interface Cheese {

    public String toString();
}
