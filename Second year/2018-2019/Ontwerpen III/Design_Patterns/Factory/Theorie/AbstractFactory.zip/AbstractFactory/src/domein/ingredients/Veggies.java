package domein.ingredients;

public interface Veggies {

    public String toString();
}
