package domein.ingredients.veggies;

import domein.ingredients.Veggies;

public class Onion implements Veggies {

    public String toString() {
        return "Onion";
    }
}
