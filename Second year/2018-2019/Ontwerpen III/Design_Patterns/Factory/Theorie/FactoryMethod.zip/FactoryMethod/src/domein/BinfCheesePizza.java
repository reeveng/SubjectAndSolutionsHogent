package domein;

public class BinfCheesePizza extends Pizza {

    public BinfCheesePizza() {
        setName("BINF Style Sauce and Cheese Pizza");
        setDough("Thin Crust Dough");
        setSauce("Marinara Sauce");

        addTopping("Grated Reggiano Cheese");
    }
}
