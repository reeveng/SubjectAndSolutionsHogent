
import domein.Duck;
import java.util.Arrays;
import java.util.Comparator;
import org.junit.Assert;
import org.junit.Test;

public class DuckTest {
    @Test
    public void sortBySizeTest() {
        Duck d1 = new Duck("Ducky", 50, 33);
        Duck d2 = new Duck("Greenie", 44, 24);
        Duck d3 = new Duck("Tutsie", 1, 105);
        Duck d4 = new Duck("Lisie", 911, 87);
        Duck[] ducks = {d1, d2, d3, d4};  
        
       //OEF 2.1 
        Arrays.sort(ducks, Comparator.comparing(Duck::getSize));
        
        //OEF 2.2
        //Arrays.sort(ducks);
        
        
        Assert.assertEquals(d2, ducks[0]);
        Assert.assertEquals(d1, ducks[1]);
        Assert.assertEquals(d4, ducks[2]);
        Assert.assertEquals(d3, ducks[3]);
    }
}
