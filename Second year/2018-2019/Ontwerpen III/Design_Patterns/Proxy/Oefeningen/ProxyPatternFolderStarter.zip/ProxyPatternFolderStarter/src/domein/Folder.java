package domein;

public class Folder {

    public String performOperations() {
        // access folder and perform various operations like copy or cut files
       return "Performing operation on folder";
    }
}
