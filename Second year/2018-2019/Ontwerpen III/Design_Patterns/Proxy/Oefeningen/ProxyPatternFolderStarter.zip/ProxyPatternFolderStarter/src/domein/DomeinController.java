package domein;

public class DomeinController {

    private UserManager userManager;
    private Folder folder;

    public DomeinController() {
        initUserManager();
        folder = new Folder();
    }

    /**
     *
     * @param name
     * @param passwd
     */
    public String performFolderOperation(String name, String passwd) {
        String mes=null;
        User user = userManager.getUser(name, passwd);
        if (user!=null){
//TODO _ maak gebruik van het proxypattern
            
            
//END TODO
        }
        else {
            mes = "Invalid user/passwd";
        }
        return mes;
    }

    private void initUserManager() {
        userManager = new UserManager();
        userManager.addUser(new User("Jan", "JanPass"), true);
        userManager.addUser(new User("Piet", "PietPass"), true);
        userManager.addUser(new User("Joris", "JorisPass"), false);
        userManager.addUser(new User("Corneel", "CorneelPass"), false);
    }
}