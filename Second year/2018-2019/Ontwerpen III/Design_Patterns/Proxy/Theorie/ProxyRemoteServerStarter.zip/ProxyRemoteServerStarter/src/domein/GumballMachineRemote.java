package domein;



public interface GumballMachineRemote  {

    int getCount() ;

    String getLocation() ;

    String getState() ;

}
