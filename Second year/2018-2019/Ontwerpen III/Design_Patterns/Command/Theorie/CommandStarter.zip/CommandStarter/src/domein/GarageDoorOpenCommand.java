package domein;

public class GarageDoorOpenCommand {

}