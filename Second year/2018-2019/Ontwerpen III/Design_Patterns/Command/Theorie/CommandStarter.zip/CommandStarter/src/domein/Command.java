package domein;

public interface Command {

    void execute();

}
