
import domein.Beyonce;

public class StartUp {

    public static void main(String args[]) {
        Beyonce beyonce1 = new Beyonce();
        Beyonce beyonce2 = new Beyonce();

        beyonce1.zingEenLied();
        beyonce2.zingEenLied();
    }

}
