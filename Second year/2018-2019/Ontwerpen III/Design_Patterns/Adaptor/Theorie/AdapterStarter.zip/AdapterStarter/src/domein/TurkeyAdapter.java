package domein;

public class TurkeyAdapter {
    }


