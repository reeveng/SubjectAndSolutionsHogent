package domein;

public interface Duck {

    void quack();
    void fly();

}
