package domein;

public interface Turkey {

    void gobble();
    void fly();

}
