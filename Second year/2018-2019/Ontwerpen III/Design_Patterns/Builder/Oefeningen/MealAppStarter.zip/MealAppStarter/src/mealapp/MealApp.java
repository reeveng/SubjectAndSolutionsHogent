package mealapp;

public class MealApp {

   public static void main(String[] args) {
      new MealApp();
   }
   
   public MealApp() {
       
        //TODO
        //System.out.printf("menu is: %s%n",                        );
        
        //System.out.printf("menu is: %s%n",                        );
    }

   
}
