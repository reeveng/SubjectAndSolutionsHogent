package domein;

public enum BreadType {
    White,
    Wheat
}
