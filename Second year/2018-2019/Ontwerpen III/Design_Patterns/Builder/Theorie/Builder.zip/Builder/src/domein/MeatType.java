package domein;

public enum MeatType {
    Turkey,
    Ham,
    Chicken,
    Salami
}
