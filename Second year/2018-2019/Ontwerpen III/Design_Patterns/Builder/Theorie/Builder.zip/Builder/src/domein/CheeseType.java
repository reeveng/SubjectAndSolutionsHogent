package domein;

public enum CheeseType {
    American,
    Swiss,
    Cheddar,
    Provolone
}
