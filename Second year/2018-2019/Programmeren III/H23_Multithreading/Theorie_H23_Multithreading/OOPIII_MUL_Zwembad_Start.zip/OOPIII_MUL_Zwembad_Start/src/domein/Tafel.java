package domein;
import java.security.SecureRandom;

// VUL DE KLASSE VERDER AAN
public class Tafel {

    private static final SecureRandom generator = new SecureRandom();
    private boolean vatLeeg = false;

    public Tafel(int aantalEmmers) {

    }

    public void vulEmmer() {

    }

    public boolean pakEmmer() {

    }

    public void setVatIsLeeg() {
        vatLeeg = true;
    }

}
