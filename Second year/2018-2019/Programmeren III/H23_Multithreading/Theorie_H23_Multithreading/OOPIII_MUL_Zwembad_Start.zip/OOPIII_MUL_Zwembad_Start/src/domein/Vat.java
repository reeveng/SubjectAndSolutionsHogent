package domein;

//VUL DE KLASSE VERDER AAN
public class Vat {

    private final Tafel tafel;
    private int inhoud;

    public Vat(int emmers, Tafel tafel) {
        inhoud = emmers;
        this.tafel = tafel;
    }

//TODO
}
