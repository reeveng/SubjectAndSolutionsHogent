package domein;


public class VerzoekLogger {
    //TODO attrib

   public  void log(String string) {
      //TODO 
      
      
      
    }
   
   public String haalLogOp(){
       //TODO
       
       return null;
   }
    
}
