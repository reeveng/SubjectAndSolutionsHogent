package domein;

import persistentie.PersistentieController;

public class Garage {
    
   // autoLijst;

    private PersistentieController persistentieController;

    public Garage() {
        persistentieController = new PersistentieController();
             
    }
  
    /*public                              getAutoLijst() {
        return 
    }*/
}
