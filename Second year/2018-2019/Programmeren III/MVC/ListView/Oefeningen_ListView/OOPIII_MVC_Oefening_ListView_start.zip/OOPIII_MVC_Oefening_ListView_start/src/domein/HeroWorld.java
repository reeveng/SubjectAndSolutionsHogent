package domein;

public class HeroWorld {
    //voorbeeld zonder databank
    private final String[] candidatesArray = {"Superman",
        "Spiderman",
        "Wolverine",
        "Thor","Police",
        "Fire Rescue","Iron Man",
        "Soldiers",
        "Dad & Mom",
        "Doctor",
        "Politician", "Teacher"};

    public HeroWorld() {
    }

}
