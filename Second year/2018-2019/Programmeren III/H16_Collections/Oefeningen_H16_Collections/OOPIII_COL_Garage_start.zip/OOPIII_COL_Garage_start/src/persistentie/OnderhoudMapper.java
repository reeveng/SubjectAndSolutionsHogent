package persistentie;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import domein.Onderhoud;

public class OnderhoudMapper {

    public List<Onderhoud> geefOnderhoudVanAutos() {
        
//    lees van bestand via een object van klasse ObjectStreamManipulaties
        
        
        return null;
    }
}
