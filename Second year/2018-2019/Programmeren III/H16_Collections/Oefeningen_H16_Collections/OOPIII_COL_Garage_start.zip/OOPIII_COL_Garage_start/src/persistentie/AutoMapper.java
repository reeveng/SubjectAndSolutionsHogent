package persistentie;

import java.util.ArrayList;
import java.util.List;

import domein.Auto;

public class AutoMapper {

    public List<Auto> geefAutos() {

//  lees van bestand via een object van klasse ObjectStreamManipulaties
        
        
        return null;
    }
}
