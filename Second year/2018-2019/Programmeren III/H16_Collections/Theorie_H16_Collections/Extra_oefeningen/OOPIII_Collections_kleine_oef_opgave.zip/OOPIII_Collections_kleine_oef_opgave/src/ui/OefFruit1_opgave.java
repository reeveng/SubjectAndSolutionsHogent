package ui;

import java.util.*;

public class OefFruit1_opgave {

    public static void main(String args[]) {
        String arX[] = {"appel", "peer", "citroen", "kiwi"},
                arY[] = {"banaan", "mango", "citroen", "kiwi", "zespri"};

        /*
	Behandel arX en arY als Collections en maak gebruik van de bulk
	peraties om volgende output te leveren:
		In y zit extra [banaan, mango, zespri]
		In x zit extra [appel, peer]
		x en y hebben gemeenschappelijk [citroen, kiwi]
         */
        
        
    }
}
