package main;

import domein.FileServer;

public class StartUp {
    public static void  main (String arg[]){
        new FileServer().run();
    }
    
}
