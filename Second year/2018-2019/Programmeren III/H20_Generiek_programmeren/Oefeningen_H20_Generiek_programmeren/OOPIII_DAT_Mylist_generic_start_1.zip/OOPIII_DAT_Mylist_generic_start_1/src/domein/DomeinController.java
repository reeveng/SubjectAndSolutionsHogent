package domein;

import persistentie.PersistentieController;

public class DomeinController {
    
    private PersistentieController pc = new PersistentieController();
        
    public void persisteerBierGegevensAlsObject(String tekstFileNaam, String objectFileNaam){
//TODO zie stap4
        //List<Bier> listBier =
        
    }
    
}
