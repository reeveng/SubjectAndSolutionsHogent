package persistentie;

import domein.Bier;
import java.io.File;
import java.util.*;

public class BierMapper {

    public List<Bier> leesBieren(File besnaam)  {
    /*TODO stap4
        List<Bier> bieren = new ArrayList<>();
        //JAVA 8:
        try (               ) {
            
            
        } catch (IOException ex) {
            Logger.getLogger(BierMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bieren;
*/
        return null;
    }

}
