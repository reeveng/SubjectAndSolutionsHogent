package domein;

public interface TebetalenTaks {

    double geefVerkeersbelasting();
}
