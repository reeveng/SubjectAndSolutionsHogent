# Feedback op de eerste deliverable

## Goed gedaan!

- groep 29, 36: goede grafiektypes! Bv. staafdiagram met error-bars, boxplot
- groep 25, 30, 37: in de samenvatting zijn alle nodige elementen aanwezig
- groep 25, 29, 30, 34, 35, 38: goede structuur/stijl van de literatuurstudie

## Ontbrekende/onvolledige zaken

- Samenvattingen zijn regelmatig onvolledig, en geven enkel een inleiding
    - Zorg dat **alle** nodige elementen aanwezig zijn!
    - Context, nood, taak, object, resultaat, conclusie, perspectief
    - Zie slides "rapporteren over onderzoek"

## Misvattingen?

- De literatuurstudie is een *doorloopende tekst over het onderwerp* van het onderzoek, met op gepaste plaatsen verwijzingen naar de geraadpleegde bronnen.
    - **Geen** verslag van het lezen van de verschillende artikels
    - **Geen** "opstel" over hoe jullie groep de literatuurstudie aangepakt heeft
    - Probeer de stijl van de artikels die jullie gelezen hebben na te bootsen!
- Een artikel/paper is geen opstel. Hanteer een professionele, [wetenschappelijke schrijfstijl](http://www.taalwinkel.nl/een-wetenschappelijke-schrijfstijl/)

Heb voldoende aandacht voor het correct invullen van **bibliografische gegevens in Jabref**! Lees de [bachelorproefgids](https://github.com/HoGentTIN/bachproef-gids/releases) voor gedetailleerde info.

- Als je literatuurlijst niet in het document staan, en de verwijzingen in de tekst zien er uit als bv. **Roediger2006** (de Bibtex-key in het vet), dan is er iets misgelopen bij het genereren van de bibliografie.
    - Zorg dat het BibTeX-bestand in Biblatex modus staat
    - Gebruik in TeXstudio "biber" voor het genereren van de literatuurlijst (Options > Configure > Build > Default bibliography tool)
    - Vraag advies tijdens een oefeningensessie!
- Veel literatuurlijsten hebben onvoldoende informatie om de bron terug te vinden.
    - Bij een @article:
        - journal: naam van het tijdschrift
        - volume: de jaargang
        - number: het nummer binnen de jaargang
        - pages (formaat mmm--nnn, dus met 2 streepjes tussen de paginanummers)
    - Bij "online", "www", "electronic" moet altijd het veld "urldate" ingevuld worden, de datum van raadplegen
- Het formaat van de auteursnamen moet zijn: "Familienaam, Voornaam and Familienaam, Voornaam and Familienaam, Voornaam and ..."
- Als in de overzichtslijst in Jabref het nummer van de publicatie in het rood verschijnt, dan is er iets fout, ontbreekt er wellicht iets. Doe de moeite om dit recht te zetten!
- "Article" is niet altijd geschikt, dus kies het juiste type publicatie. Bv. ergens is een thesis geclassificeerd als Article

## Presentatie/vorm

- Gebruik enkel het aangereikte sjabloon en verander daar ook niets aan (bv. stijl van refereren)
- Trek geen besluiten enkel op basis van een vergelijking van gemiddelden!
    - Hou ook rekening met de spreiding.
    - Gebruik dan ook geschikte grafiektypes, bv. boxplot, staafdiagram met error-bars