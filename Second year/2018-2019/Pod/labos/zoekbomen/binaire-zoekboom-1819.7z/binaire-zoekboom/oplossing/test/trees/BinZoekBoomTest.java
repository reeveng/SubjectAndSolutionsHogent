package trees;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 *
 * @author Stijn Lievens
 */
public class BinZoekBoomTest {
    
    @Test
    public void testVoegToe() {
        System.out.println("testVoegToe");       
        BinZoekBoom<Integer, String> boom = new BinZoekBoom<>();
        boom.voegToe(1, "a");
        assertEquals("a", boom.getWaarde(1));               
    }
    
    @Test
    public void testVoegToe2() {
        System.out.println("testVoegToe2");       
        BinZoekBoom<Integer, String> boom = new BinZoekBoom<>();
        boom.voegToe(1, "a");
        assertEquals("a", boom.getWaarde(1));
        boom.voegToe(5, "e");
        assertEquals("e", boom.getWaarde(5));
        boom.voegToe(3, "c");
        assertEquals("c", boom.getWaarde(3));
    }
    
    @Test
    public void testGrootte() {
        System.out.println("testGrootte");
        BinZoekBoom<Integer, String> boom = new BinZoekBoom<>();
        List<Integer>  lijst = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            lijst.add(i);
        }
        Collections.shuffle(lijst);
        for (int i : lijst) {
            boom.voegToe(i, String.valueOf((char)('a' + i)));
        }
        assertEquals(26, boom.grootte());        
    }
    
    @Test
    public void testGrootteLeeg() {
        System.out.println("testGrootteLeeg");
        BinZoekBoom<Integer, String> boom = new BinZoekBoom<>();
        assertEquals(0, boom.grootte());
    }
    
    @Test
    public void testVerwijderKleinste() {
        System.out.println("testVerwijderKleinste");
        BinZoekBoom<Integer, String> boom = new BinZoekBoom<>();
        List<Integer>  lijst = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            lijst.add(i);
        }
        Collections.shuffle(lijst);
        for (int i : lijst) {
            boom.voegToe(i, String.valueOf((char)('a' + i)));
        }        
        assertEquals("a", boom.getWaarde(0));
        boom.verwijderKleinste();
        assertNull(boom.getWaarde(0));
        assertEquals("b", boom.getWaarde(1));
        boom.verwijderKleinste();
        assertNull(boom.getWaarde(1));
    }
    
    @Test
    public void testVerwijder() {
        System.out.println("testVerwijder");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {8,3,10,1,6,14,4,7,13};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        boom.verwijder(4);
        for (int i : sleutels) {
           if (i != 4) {
               assertEquals(i, (int) boom.getWaarde(i));
           } else {
               assertNull(boom.getWaarde(i));
           }
           
        }
        // controleer dat de vorm van de boom ook nog steeds juist is
        assertEquals( 
                "(8,(3,(1,,),(6,,(7,,))),(10,,(14,(13,,),)))", 
                boom.tekenBoom());
    }
    
    @Test
    public void testVerwijder2() {
        System.out.println("testVerwijder2");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {8,3,10,1,6,14,4,7,13};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        boom.verwijder(10);
        for (int i : sleutels) {
           if (i != 10) {
               assertEquals(i, (int) boom.getWaarde(i));
           } else {
               assertNull(boom.getWaarde(i));
           }           
        }
        assertEquals( 
                "(8,(3,(1,,),(6,(4,,),(7,,))),(14,(13,,),))", 
                boom.tekenBoom());
    }
    
    @Test
    public void testVerwijder3() {
        System.out.println("testVerwijder3");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {8,3,10,1,6,14,4,7,13};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        boom.verwijder(8);
        for (int i : sleutels) {
           if (i != 8) {
               assertEquals(i, (int) boom.getWaarde(i));
           } else {
               assertNull(boom.getWaarde(i));
           }           
        }
        assertEquals( 
                "(10,(3,(1,,),(6,(4,,),(7,,))),(14,(13,,),))", 
                boom.tekenBoom());
    }
    
    @Test
    public void testVerwijder4() {
        System.out.println("testVerwijder4");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }       
        boom.verwijder(8);       
        for (int i : sleutels) {
           if (i != 8) {              
               assertEquals(i, (int) boom.getWaarde(i));
           } else {
               assertNull(boom.getWaarde(i));
           }           
        }
    }
    
    @Test 
    public void testVerwijder5() {
        System.out.println("testVerwijder5");
        // boom met 1 top moet leeg zijn als de enige top wordt verwijderd
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        boom.voegToe(100, 100);
        assertEquals(1, boom.grootte());
        boom.verwijder(100);
        assertEquals(0,  boom.grootte());
    }
           
    
    @Test
    public void tekenBoomTest() {
        System.out.println("tekenBoomTest");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        boom.voegToe(1,1);
        assertEquals("(1,,)", boom.tekenBoom());
    }
    
    @Test
    public void tekenBoomTest2() {
        System.out.println("tekenBoomTest2");       
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {8,3,10,1,6,14,4,7,13};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        
        assertEquals( 
                "(8,(3,(1,,),(6,(4,,),(7,,))),(10,,(14,(13,,),)))", 
                boom.tekenBoom());
    }
    
    @Test
    public void testFloor() {
        System.out.println("testFloor");       
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {8,3,10,1,6,14,4,7,13};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        assertEquals(1, (int) boom.floor(2));
        assertEquals(14, (int) boom.floor(14));
        assertEquals(14, (int) boom.floor(15));
        assertEquals(10, (int) boom.floor(12));
        assertNull(boom.floor(0));
    }
    
    @Test
    public void testSleutels() {
        System.out.println("testSleutels");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        }
        
        List<Integer> s = boom.sleutels();       
        Arrays.sort(sleutels);
        for (int i = 0; i < sleutels.length; i++) {
            assertEquals(sleutels[i], (int) s.get(i));
        }
    }
    
    @Test
    public void testSleutels2() {
        System.out.println("testSleutels2");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        int laag = 5;
        int hoog = 15;
        List<Integer> s = boom.sleutels(laag, hoog);
        Arrays.sort(sleutels);
        int j = 0;
        for (int i = 0; i < sleutels.length; i++) {
            if (laag <= sleutels[i]  && sleutels[i] <= hoog) {
               assertEquals( sleutels[i], (int) s.get(j));
               j++;
            }
        }
        assertEquals(j, s.size()); // controleer aantal elementen                
    }
    
    @Test
    public void testSleutels3() {        
        System.out.println("testSleutels3");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        // haal alle elementen op
        int laag = Integer.MIN_VALUE;
        int hoog = Integer.MAX_VALUE;
        List<Integer> s = boom.sleutels(laag, hoog);
        List<Integer> s2 = boom.sleutels();
        
        assertEquals(s, s2);
    }
    
    @Test
    public void testSleutels4() {        
        System.out.println("testSleutels4");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        // haal geen enkel element op, alle gevraagde elementen kleiner
        int laag = Integer.MIN_VALUE;
        int hoog = Integer.MIN_VALUE + 1000;
        List<Integer> s = boom.sleutels(laag, hoog);        
        
        assertTrue(s.isEmpty());
    }
    
    @Test
    public void testSleutels5() {        
        System.out.println("testSleutels5");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        // haal geen enkel element op, alle gevraagde elementen groter
        int laag = Integer.MAX_VALUE - 1000;
        int hoog = Integer.MAX_VALUE ;
        List<Integer> s = boom.sleutels(laag, hoog);        
        
        assertTrue(s.isEmpty());
    }
    
    @Test
    public void testHoogte() {
        System.out.println("testHoogte");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        assertEquals(4, boom.hoogte());
        boom.voegToe(23,23);
        boom.voegToe(22,22);
        assertEquals(5, boom.hoogte());
    }
    
    @Test
    public void testGetKleinste() {
        System.out.println("getKleinste");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        assertEquals(Integer.valueOf(2), boom.getKleinste());        
    }
    
    @Test
    public void testHoogteEenTop() {
        System.out.println("testHoogteEenTop");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        boom.voegToe(100, 100);
        assertEquals(0, boom.hoogte());
    }
    
    @Test
    public void testHoogteLeeg() {
        System.out.println("testHoogteLeeg");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        assertEquals(-1, boom.hoogte());
    }
    
    @Test
    public void stressTest() {
        System.out.println("stressTest");
        List<Integer> ints = IntStream.rangeClosed(1, 1024*1024)
                .boxed().collect(Collectors.toList());
        Collections.shuffle(ints, new Random(42));
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        for (Integer i : ints) {
            boom.voegToe(i, i);
        }
        assertEquals(1024*1024, boom.grootte());
        System.out.println("boom.hoogte = " + boom.hoogte());
    }
    
    // Aangezien de implementatie recursief is verwachten we hier een 
    // stackoverflow
    // Een iteratieve implementatie zal dit probleem niet vertonen.
    @Test(expected = StackOverflowError.class) 
    public void stressTest2() {
        System.out.println("stressTest2");
        List<Integer> ints = IntStream.rangeClosed(1, 1024*1024)
                .boxed().collect(Collectors.toList());       
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        for (Integer i : ints) {
            boom.voegToe(i, i);
        }
        assertEquals(1024*1024, boom.grootte());
        System.out.println("boom.hoogte = " + boom.hoogte());
    }
    
    
    @Test
    public void testGetWaarde() {
        System.out.println("getGetWaarde");
        BinZoekBoom<Integer, Integer> boom = new BinZoekBoom<>();
        int [] sleutels = {15,8,20,5,11,18,25,3,6,9,12,17,21,28,2,4,10,14,26,30};
        for (int i : sleutels) {
            boom.voegToe(i, i);
        } 
        assertNull(boom.getWaarde(7));
    }
    
}
