package trees;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Stijn Lievens
 * @param <K> het type van de sleutel (key)
 * @param <V> het type van de waarde  (value)
 */
public class BinZoekBoom<K extends Comparable<K>, V> {
    
    private Top wortel; // de wortel van de binaire zoekboom

   /**
    * Om gemakkelijk sleutels te vergelijken
    */
    private enum Result {
        KLEINER, GELIJK, GROTER;
    }
    
    /**
     * Vergelijkt twee sleutels
     * @param k1 de eerste sleutel
     * @param k2 de tweede sleutel
     * @return KLEINER als <code>k1 < k2</code>, 
     * GROTER als  <code>k2 < k1</code> en GELIJK als  <code>k1 == k2</code>.
     */
    private Result compare(K k1, K k2) {
        int cmp = k1.compareTo(k2);
        return cmp < 0 ? Result.KLEINER : 
                (cmp > 0 ? Result.GROTER : Result.GELIJK);
    }
    /**
     * Stelt een top van de binaire zoekboom voor.
     */
    private class Top {
        private K sleutel;
        private V waarde;
        private Top links, rechts;
        
        public Top(K sleutel, V waarde) {
            this.sleutel = sleutel;
            this.waarde = waarde;
        }        
    }
    
    /**
     * Geeft het aantal toppen van de binaire zoekboom terug.
     * 
     * @return het aantal toppen van de binaire zoekboom.
     */
    public int grootte() {
        return grootte(wortel);               
    }
    
    private int grootte(Top t) {
        throw new UnsupportedOperationException("grootte");
    }
    
    /**
     * Geeft de waarde die bij de sleutel hoort, of null indien de sleutel
     * niet bestaat in de zoekboom.
     * 
     * @param sleutel de te zoeken sleutelwaarde
     * @return de waarde die bij de sleutel hoort, of null indien de sleutel
     * niet bestaat in de zoekboom
     */
    public V getWaarde(K sleutel) {
        return getWaarde(wortel, sleutel);
    }
    
    private V getWaarde(Top t, K sleutel) {
         throw new UnsupportedOperationException("getWaarde");
    }
    
    /**
     * Voeg een nieuwe top toe met de gegeven sleutel en bijhorende waarde.
     * Indien de sleutel reeds bestaat dan wordt een nieuwe waarde geassocieerd
     * met deze sleutel.
     * 
     * @param sleutel de sleutel
     * @param waarde  de bijhorende waarde
     */
    public void voegToe(K sleutel, V waarde) {
        wortel = voegToe(wortel, sleutel, waarde);
    }
    
    
    /**
     * 
     * @param t de wortel van de deelboom waar de nieuwe top moet aan 
     * toegevoegd worden
     * @param sleutel de sleutel
     * @param waarde  de bijhorende waarde
     * @return de wortel van de (deel)boom die de (nieuwe) top bevat
     */
    private Top voegToe(Top t, K sleutel, V waarde) {
        throw new UnsupportedOperationException("voegToe");           
    }
    
    /** 
     * Geef de waarde die hoort bij de kleinste sleutel.
     * 
     * @return de waarde die hoort bij de kleinste sleutel
     */
    public V getKleinste() {
        if (wortel == null) {
            return null;
        }
        return getKleinste(wortel).waarde;
    }
    
    /**
     * Geef de top die hoort bij de kleinste sleutel.
     * 
     * @param t de wortel van de deelboom waarin de kleinste moet gezocht
     * worden
     * @return de top die de kleinste sleutel bevat
     */
    private Top getKleinste(Top t) {
         throw new UnsupportedOperationException("getKleinste");
    }
    
    /**
     * Verwijdert de top met de  kleinste sleutel uit de boom.
     */
    public void verwijderKleinste() {
        if (wortel != null) {
          wortel = verwijderKleinste(wortel);
        }
    }
    
   
    /**
     * Verwijdert de top met de  kleinste sleutel uit de boom met wortel t.
     * 
     * @param t de wortel van de deelboom
     * @return de (nieuwe) wortel van de deelboom nadat de kleinste werd 
     * verwijderd.
     */
    private Top verwijderKleinste(Top t) {
        throw new UnsupportedOperationException("verwijderKleinste");
    }

    /**
     * Verwijdert de top met de gegeven sleutel uit de boom.
     * 
     * @param sleutel de sleutel van de te verwijderen top
     */
    public void verwijder(K sleutel) {
        wortel = verwijder(wortel, sleutel);
    }
    
    /**
     * Verwijdert de top met de gegeven sleutel uit de boom.
     * 
     * @param t de wortel van de deelboom waaruit de sleutel moet verwijderd
     * worden
     * @param sleutel de sleutel van de te verwijderen top
     * @return de wortel van de (nieuwe) deelboom nadat de sleutel werd
     * verwijderd
     */
    private Top verwijder(Top t, K sleutel) {
         throw new UnsupportedOperationException("verwijder");
     }
    
    /**
     * Geeft de hoogte van de boom.
     * 
     * @return 
     */
    public int hoogte() {
        return hoogte(wortel);
    }
    
   /**
    * Geeft de hoogte van de boom met wortel t.
    * 
    * @param t de wortel van de deelboom
    */
    private int hoogte(Top t) {
        throw new UnsupportedOperationException("hoogte");
    }
    
    /**
     * Geeft een lijst van sleutels terug in stijgende volgorde.
     * 
     * @return een gesorteerde lijst van sleutels  
     */
    public List<K> sleutels() {
        List<K> s = new ArrayList<>();
        sleutels(wortel, s);
        return s;        
    }
    
     /**
     * Geeft een lijst van sleutels terug in stijgende volgorde.
     * 
     * @param t de wortel van de deelboom
     * @param s de lijst van sleutels die moet aangevuld worden
     */
     private void sleutels(Top top, List<K> s) {
        throw new UnsupportedOperationException("sleutels");   
     }
     
     /**
      * Geeft een lijst van sleutels terug in stijgende volgorde, waarbij
      * deze sleutels tussen de grenzen laag en hoog liggen.
      * 
      * @param laag ondergrens voor de sleutels (inbegrepen)
      * @param hoog bovengrens voor de sleutels (inbegrepen)
      * @return lijst van sleutels tussen laag en hoog, grenzen inbegrepen
      */
     public List<K> sleutels(K laag, K hoog) {
        List<K> s = new ArrayList<>();
        sleutels(wortel, s, laag, hoog);
        return s;    
     }
     
     /**
      * 
      * @param t de wortel van de beschouwde deelboom
      * @param s de sleutels tot nu toe
      * @param laag ondergrens voor de sleutels (inbegrepen)
      * @param hoog bovengrens voor de sleutels (inbegrepen)
      */
     private void sleutels(Top t, List<K> s, K laag, K hoog) {
         throw new UnsupportedOperationException("sleutels");  
     }
    
    /**
     * Grafische representatie van de sleutels van de boom.
     * 
     * @return String met grafische representatie van de sleutels van de boom. 
     */
    public String tekenBoom() {
        return tekenBoom(wortel).toString();
    }
    
    // gegeven
    private StringBuilder tekenBoom(Top t) {
        if (t == null) {
            return new StringBuilder();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("(").append(t.sleutel).append(",");
        sb.append(tekenBoom(t.links));
        sb.append(",");
        sb.append(tekenBoom(t.rechts));
        sb.append(")");
        return sb;
    }
    
    /**
     * Geef de grootste sleutel terug die hoogstens gelijk is aan de gegeven
     * sleutel.
     * 
     * @param sleutel de gegeven sleutel
     * @return de grootste sleutel die hoogstens gelijk is aan de gegeven 
     * sleutel
     */
    public K floor(K sleutel) {
        return floor(wortel, sleutel, null);
    }
    
    private K floor(Top t, K sleutel, K f) {
       throw new UnsupportedOperationException("floor");   
    }         
}
