package persistentie;

import domein.Land;

public class LandMapper {

    public Land findLand(String code) {
        //naar de database
        return null;
    }

    public int findOppervlakteAlleLanden() {
        //naar de database
        return 0;
    }
}
