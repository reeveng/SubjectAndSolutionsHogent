package persistentie;

import domein.Land;

public class PersistentieController {

    private LandMapper landMapper;

    public Land findLand(String code) {
        if (landMapper == null) {
            landMapper = new LandMapper();
        }
        return landMapper.findLand(code);
    }

    public int findOppervlakteAlleLanden() {
        if (landMapper == null) {
            landMapper = new LandMapper();
        }
        return landMapper.findOppervlakteAlleLanden();
    }

}
