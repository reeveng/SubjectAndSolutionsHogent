package domein;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;

public class Jackpot {

    private final static int DEFAULT_AANTAL_ROLLEN = 3;
    private final static int DEFAULT_AANTAL_SYMBOLEN = 6;

    private Rol[] rollen;

    public Jackpot() {
        rollen = new Rol[DEFAULT_AANTAL_ROLLEN];
        Arrays.fill(rollen, new Rol(DEFAULT_AANTAL_SYMBOLEN));
    }

    public DraaiResult draai() {
        Integer[] lijn = doeEenDraai();
        boolean gewonnen = controleGewonnen(lijn);
        return new DraaiResult(lijn, gewonnen);
    }

    private Integer[] doeEenDraai() {
        Integer[] lijn = new Integer[rollen.length];
        IntStream.range(0, rollen.length).
                forEach(rolIndex -> lijn[rolIndex] = rollen[rolIndex].draaiRol());
        return lijn;
    }

    private boolean controleGewonnen(Integer[] result) {

        List<Integer> resultList = Arrays.asList(result);
        Set<Integer> resultSet = new HashSet<>(resultList);
        return (resultSet.size() < resultList.size());
    }

}
