package domein;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collections;

public class Rol {

    private final Integer[] symbolenOpRol;
    private final SecureRandom random = new SecureRandom();

    public Rol(int aantalSymbolen) {
        symbolenOpRol = new Integer[aantalSymbolen];

        for (int symbool = 1, index = 0; symbool <= aantalSymbolen; symbool++) {
            symbolenOpRol[index++] = symbool;
        }

        Collections.shuffle(Arrays.asList(symbolenOpRol));
    }

    public int draaiRol() {
        int draaitTotPositie = random.nextInt(symbolenOpRol.length);
        return symbolenOpRol[draaitTotPositie];
    }

}
