package domein;

public class DraaiResult {

    private final Integer[] lijn;
    private final boolean gewonnen;

    DraaiResult(Integer[] result, boolean gewonnen) {
        lijn = result;
        this.gewonnen = gewonnen;
    }

    public Integer[] getLijn() {
        return lijn;
    }

    public boolean isGewonnen() {
        return gewonnen;
    }
}
