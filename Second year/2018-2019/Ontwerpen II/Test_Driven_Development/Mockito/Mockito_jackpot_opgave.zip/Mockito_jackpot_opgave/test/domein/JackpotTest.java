package domein;

import org.junit.Test;

public class JackpotTest {

    public JackpotTest() {
    }

}
