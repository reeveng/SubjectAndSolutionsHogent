package domein;

import java.util.List;
import persistentie.PersistentieController;

public class BierWinkel
{
    private List<Bier> bieren;
    private PersistentieController pc=new PersistentieController();

    public BierWinkel()
    {
        bieren = pc.inlezenBieren("bieren.txt");
    }
    
    public long geefAantalBierenMetHogereBeoordeling(double beoordeling) {
        if (beoordeling < 0 || beoordeling > 10) {
            return 0;
        }
        return bieren.stream().
                filter(bier -> bier.getBeoordeling() >= beoordeling).count();
    }
    
}
