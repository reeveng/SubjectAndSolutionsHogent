package persistentie;

import domein.Bier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BierMapper {

    public List<Bier> inlezenBieren(String naamBestand) {
        //Voorbeeld zonder databank. Stel dat er over de honderd bieren in de databank staan.
        Bier[] bierenArray = {new Bier("WestVleteren_Blond", "blond", 5.0, 9.3, "Sint-Sixtusabdij van Westvleteren"),
            new Bier("Tripel_Kanunnik", "tripel", 8.2, 7.1, "Wilderen"),
            new Bier("WestVleteren_Blond", "donker", 13.0, 5.0, "De Struise Brouwers")};
        return new ArrayList<>(Arrays.asList(bierenArray));
    }

}
