package domein;

import org.junit.Test;
import org.junit.Assert;

public class BierWinkelTest {
    
        private final Bier[] BIEREN
            = {new Bier("WestVleteren_Blond", "blond", 5.0, 9.1, 
                                   "Sint-Sixtusabdij van Westvleteren"),
                new Bier("Tripel_Kanunnik", "tripel", 8.2, 7.1, "Wilderen"),
                new Bier("WestVleteren_Blond", "donker", 13.0, 5.5, 
                                    "De Struise Brouwers")};
    
}
