package domein;

public class DomeinController {

    private BierWinkel bierWinkel;

    public DomeinController() {
        bierWinkel = new BierWinkel();
    }

    public long geefAantalBieren(double beoordeling) {
        return bierWinkel.geefAantalBierenMetHogereBeoordeling(beoordeling);
    }

}
