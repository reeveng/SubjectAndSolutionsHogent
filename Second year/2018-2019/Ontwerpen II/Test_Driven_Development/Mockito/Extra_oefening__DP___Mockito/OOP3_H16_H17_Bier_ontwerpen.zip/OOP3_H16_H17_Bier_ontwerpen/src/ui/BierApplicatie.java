package ui;

import domein.DomeinController;

public class BierApplicatie {

    private final DomeinController domeinController;

    public BierApplicatie(DomeinController domeinController) {
        this.domeinController = domeinController;
    }

    public void start() {
        System.out.println("Aantal bieren met beoordeling groter of gelijk aan 6: " + domeinController.geefAantalBieren(6));
    }

}
