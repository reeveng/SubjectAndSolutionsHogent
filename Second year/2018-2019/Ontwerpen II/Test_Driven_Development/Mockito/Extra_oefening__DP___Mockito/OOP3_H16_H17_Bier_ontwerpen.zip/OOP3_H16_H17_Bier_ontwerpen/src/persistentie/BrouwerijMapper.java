package persistentie;

import domein.Brouwerij;
import java.util.List;

public class BrouwerijMapper {

    public List<Brouwerij> inlezenBrouwerijen(String naamBestand) {
        return null;
    }

}
