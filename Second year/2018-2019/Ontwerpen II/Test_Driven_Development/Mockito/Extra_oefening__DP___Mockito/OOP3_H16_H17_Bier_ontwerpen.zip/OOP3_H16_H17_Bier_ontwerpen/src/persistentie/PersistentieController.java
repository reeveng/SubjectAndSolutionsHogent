package persistentie;

import domein.Bier;
import domein.Brouwerij;
import java.util.List;

public class PersistentieController
{
  private BierMapper bierMapper;
    private BrouwerijMapper brouwerijMapper;
    
    public List<Bier> inlezenBieren(String naamBestand) {
        if (bierMapper == null)
            bierMapper = new BierMapper();
        return bierMapper.inlezenBieren(naamBestand);
    }

    public List<Brouwerij> inlezenBrouwerijen(String naamBestand) {
        if (brouwerijMapper == null)
            brouwerijMapper = new BrouwerijMapper();
        return brouwerijMapper.inlezenBrouwerijen(naamBestand);
    }

}
