package persistentie;

public class ContinentMapper {

    public long findAantalBewoners(String continent) {
        //naar de database
        return 0;
    }

    public long findGeboortecijfers(String continent) {
        //naar de database
        return 0;
    }

    public long findSterfteCijfer(String continent) {
        //naar de database
        return 0;
    }
}
