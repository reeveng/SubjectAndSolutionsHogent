package domein;

public interface WeegschaalInit {

    Double MAX = 5.0;
    Double NAUWKEURIGHEID = 0.0000000000001;
}
