package domein;

import org.junit.Test;
import org.junit.Assert;

public class WeegschaalOverbelasting {
    
}
