package domein;

import java.util.Arrays;

public class VeelvoudSpel {
    
    private Teerling[] teerlingen; 
    
    public VeelvoudSpel(int aantal)
    {
        if (aantal <= 0)
            throw new IllegalArgumentException("aantal teerlingen moet positief zijn");
        teerlingen = new Teerling[aantal];
        Arrays.fill(teerlingen, new Teerling());
    }
    
    public boolean speel(int veelvoud)
    {
        int som =Arrays.stream(teerlingen).mapToInt(t -> t.gooi()).sum();
        return (som % veelvoud == 0);
    }
}
