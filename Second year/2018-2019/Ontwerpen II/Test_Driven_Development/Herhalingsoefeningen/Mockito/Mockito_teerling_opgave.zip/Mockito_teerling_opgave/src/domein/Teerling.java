package domein;

import java.security.SecureRandom;

public class Teerling {

    private final int AANTAL_VLAKKEN = 6;
    private final SecureRandom random = new SecureRandom();

    public int getAantalVlakken() {
        return AANTAL_VLAKKEN;
    }

    public int gooi() {
        return random.nextInt(AANTAL_VLAKKEN) + 1;
    }

}
