package domein;

public class SimpleCraps {

    public boolean speel() {
        Teerling teerling = new Teerling();
        int eerste_worp = teerling.gooi();
        switch (eerste_worp) {
            case 2:
                return true;
            case 3:
                return false;
        }
        do {
            int worp = teerling.gooi();
            if (worp == eerste_worp) {
                return true;
            }
            if (worp == 2) {
                return false;
            }
        } while (true);
    }
}
