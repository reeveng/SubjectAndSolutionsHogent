package domein;

import org.junit.Test;
import org.junit.Assert;
import org.junit.Before;

public class VeelvoudSpelTest {

}
