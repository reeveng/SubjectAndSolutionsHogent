package domein;

public class FlyRocketPowered implements FlyBehavior {

    @Override
    public String fly() {
        return "Ik vlieg met raketaandrijving";
    }
}
