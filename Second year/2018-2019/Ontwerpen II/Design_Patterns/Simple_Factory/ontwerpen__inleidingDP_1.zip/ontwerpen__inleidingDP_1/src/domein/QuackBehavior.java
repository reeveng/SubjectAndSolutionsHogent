package domein;

public interface QuackBehavior {

    public String quack();
}
