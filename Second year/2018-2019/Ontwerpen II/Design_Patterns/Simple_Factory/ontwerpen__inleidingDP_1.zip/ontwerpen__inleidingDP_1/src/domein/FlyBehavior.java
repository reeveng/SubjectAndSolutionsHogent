package domein;

public interface FlyBehavior {

    public String fly();
}
