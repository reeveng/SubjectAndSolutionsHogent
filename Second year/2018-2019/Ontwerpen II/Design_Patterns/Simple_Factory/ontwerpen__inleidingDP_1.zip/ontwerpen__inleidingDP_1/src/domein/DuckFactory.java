package domein;

public class DuckFactory {

    
/*
        switch (            ) {
            case    :
                return new RedheadDuck(new Quack(), new FlyWithWings());
            case    :
                return new MallardDuck(new Quack(), new FlyWithWings());
            case    :
                return new RubberDuck(new Squeak(), new FlyNoWay());
            case    :
                return new DecoyDuck(new MuteQuack(), new FlyNoWay());
  
 */   
        
    
}
