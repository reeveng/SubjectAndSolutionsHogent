package domain;

import java.io.File;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TestFileState {

    private FileEditor file;

    @Before
    public void before() {
        file = new FileEditor(new File("opgave"));
    }

    @Test
    public void testInitState() {
        Assert.assertFalse(file.save());
    }

    @Test
    public void testNaarCleanState() {

        file.edit();

        //Van dirty naar clean
        Assert.assertTrue(file.save());

        Assert.assertFalse(file.save());
    }

    @Test
    public void testNaarDirtyState() {
        //Van clean naar dirty
        Assert.assertTrue(file.edit());

        Assert.assertFalse(file.edit());

        file.save();

        //Van clean naar dirty
        Assert.assertTrue(file.edit());
    }
}