package domain;

import java.io.File;

public class FileEditor {

    private final File file;

    public FileEditor(File file) {
        this.file = file;
    }

}
