package gui;

import domein.DierSoort;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

public class KnoppenPaneelController extends GridPane{

    @FXML
    private Button btnKatToevoegen;

    @FXML
    private Button btnHondToevoegen;

    //OPLOSSING 1TI: KnoppenPaneel kent DierenScherm
    //VERBETERING Ontwerpen II
   private final DierenSchermController hoofdPaneel;

    public KnoppenPaneelController(DierenSchermController hoofdPaneel) {
        this.hoofdPaneel = hoofdPaneel;

        FXMLLoader loader = new FXMLLoader(getClass().getResource("KnoppenPaneel.fxml"));
        loader.setRoot(this);
        loader.setController(this);
        try {
            loader.load();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    @FXML
    private void katToevoegen(ActionEvent event) 
    {
        hoofdPaneel.startDierToevoegenScherm(DierSoort.KAT);
    }

    @FXML
    private void hondToevoegen(ActionEvent event) {
        hoofdPaneel.startDierToevoegenScherm(DierSoort.HOND);
    }

}
