package domein;

import java.util.Calendar;
import java.util.GregorianCalendar;

public abstract class Dier {

    private int geboortejaar;

    public Dier(int geboortejaar) {
        setGeboortejaar(geboortejaar);
    }

    public int getGeboortejaar() {
        return geboortejaar;
    }

    public void setGeboortejaar(int geboortejaar) {
        if (geboortejaar > huidigJaar()) {
            throw new IllegalArgumentException(
                    "geboortejaar moet kleiner of gelijk zijn aan het huidig jaar");
        }
        this.geboortejaar = geboortejaar;
    }

    protected int huidigJaar() {
        Calendar cal = new GregorianCalendar();
        return cal.get(Calendar.YEAR);
    }

    public int leeftijd() {
        return huidigJaar() - geboortejaar;
    }

    public abstract int leeftijdVolgensMens();

    public String toString() {
        return String.format(
                "%s: leeftijd is %d en volgens de mens %d",
                this.getClass().getSimpleName().toUpperCase(),
                leeftijd(), leeftijdVolgensMens());
    }

}
