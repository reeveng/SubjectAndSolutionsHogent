package persistentie;

import java.util.ArrayList;
import java.util.List;

import domein.Dier;
import domein.Hond;
import domein.Kat;

public class DierenMapper {

    public List<Dier> geefDieren() {
        //Simulatie databank
        List<Dier> dier = new ArrayList<>();
        dier.add(new Kat(2003));
        dier.add(new Hond(2005, "Fluffy"));
        dier.add(new Kat(2010));
        dier.add(new Hond(2004, "Lady"));
        return dier;
    }
}
