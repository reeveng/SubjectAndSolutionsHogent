package domein;

public class Kat extends Dier {

    private final int MAX_LEEFTIJD = 27;
    
    public Kat(int geboortejaar) {
        super(geboortejaar);
    }

    @Override
    public void setGeboortejaar(int geboortejaar) {
        if (huidigJaar() - geboortejaar > MAX_LEEFTIJD) {
            throw new IllegalArgumentException(
                    "leeftijd van een kat is maximaal " + MAX_LEEFTIJD + " jaar");
        }
        super.setGeboortejaar(geboortejaar);
    }

    @Override
    public int leeftijdVolgensMens() {
        return leeftijd() * 7;
    }
}
