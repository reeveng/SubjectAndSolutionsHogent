package domein;

import java.util.List;
import persistentie.PersistentieController;

public class DierenVerzameling {

    private PersistentieController persistentieController;

    private List<Dier> dieren;

    public DierenVerzameling() {
        persistentieController = new PersistentieController();
        dieren = persistentieController.geefDieren();
    }

    public List<Dier> getDieren() {
        return dieren;
    }

    public void toevoegenDier(String geboortejaarS) {
        if (geboortejaarS.length() == 0) {
            throw new IllegalArgumentException(
                    "geboortejaar moet ingevuld worden");
        }

        int geboortejaar = omzettenGeboortejaar(geboortejaarS);
        Dier nieuwDier = new Kat(geboortejaar);
        dieren.add(nieuwDier);
    }

    public void toevoegenDier(String naam, String geboortejaarS) {
        if (geboortejaarS.length() == 0 || naam.length() == 0) {
            throw new IllegalArgumentException(
                    "velden moeten ingevuld worden");
        }
        int geboortejaar = omzettenGeboortejaar(geboortejaarS);
        Dier nieuwDier = new Hond(geboortejaar, naam);
        dieren.add(nieuwDier);
    }

    private int omzettenGeboortejaar(String geboortejaarS) {
        int geboortejaar;
        try {
            geboortejaar = Integer.parseInt(geboortejaarS);
        } catch (NumberFormatException e) {
            throw new NumberFormatException("geboortejaar moet een geheel getal zijn");
        }
        return geboortejaar;
    }

    public String toonOverzicht() {
        if (dieren.isEmpty()) {
            return "verzameling dieren is leeg";
        }

        String resul = "";
        resul = dieren.stream().map((eenDier) -> eenDier.toString()+"\n").reduce(resul, String::concat);

        //JAVA 7
        /*
        String resul = "";
        for (Dier eenDier : dieren) {
            resul += eenDier + "\n"; // eenDier.toString()
        }
        */
        
        return resul;
    }
}
