package gui;

import domein.DierSoort;
import domein.DierenVerzameling;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class DierToevoegenSchermController extends GridPane {

    private Button btnOk;

    private Button btnCancel;

    private String[] titelAttributen;

    private TextField[] txtAttributen;

    private DierenVerzameling domeinController;

    private DierSoort dierSoort;

    public DierToevoegenSchermController(DierenVerzameling domeinController, DierSoort dierSoort) {

        this.domeinController = domeinController;
        this.dierSoort = dierSoort;
        this.titelAttributen = dierSoort.attribuutNamen();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("DierToevoegenScherm.fxml"));
        loader.setRoot(this);
        loader.setController(this);
        try {
            loader.load();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        txtAttributen = new TextField[titelAttributen.length];

        for (int rij = 0; rij < titelAttributen.length; rij++) {
            Label label = new Label(titelAttributen[rij]);

            label.setId("fancytext");
            //OF slecht:
            // label.setStyle("#fancytext {-fx-fill: white;-fx-font: 14px Harlow; }");

            add(label, 0, rij);
            txtAttributen[rij] = new TextField();
            add(txtAttributen[rij], 1, rij);
        }

        btnOk = new Button();
        btnOk.setText("OK");
        btnOk.setMinSize(200, 70);
        btnOk.setOnAction(this::ok);
        add(btnOk, 0, titelAttributen.length);

        btnCancel = new Button();
        btnCancel.setText("Cancel");
        btnCancel.setMinSize(200, 70);
        btnCancel.setOnAction(this::cancel);
        add(btnCancel, 1, titelAttributen.length);
    }

    private void ok(ActionEvent event) {

        try {
            switch (dierSoort) {
                case KAT:
                    domeinController.toevoegenDier(txtAttributen[0].getText());
                    break;
                case HOND:
                    domeinController.toevoegenDier(txtAttributen[0].getText(),
                            txtAttributen[1].getText());
                    break;
            }

            Stage stage = (Stage) btnOk.getScene().getWindow();
            stage.close();

        } catch (IllegalArgumentException e) {
         new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }

    }

    private void cancel(ActionEvent event) {
        Stage stage = (Stage) btnCancel.getScene().getWindow();
        stage.close();
    }
}
