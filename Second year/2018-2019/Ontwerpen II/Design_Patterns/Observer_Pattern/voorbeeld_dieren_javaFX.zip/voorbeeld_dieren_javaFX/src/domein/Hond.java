package domein;

public class Hond extends Dier {

    private String naam;

    public Hond(int geboortejaar, String naam) {
        super(geboortejaar);
        setNaam(naam);
    }

    public Hond(int geboortejaar) {
        this(geboortejaar, "onbekend");
    }

    public void setNaam(String naam) {
        if (naam.length() == 0) {
            throw new IllegalArgumentException("naam moet ingevuld zijn");
        }
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }

    public void setGeboortejaar(int geboortejaar) {
        if (huidigJaar() - geboortejaar > 29) {
            throw new IllegalArgumentException("leeftijd van een hond is maximaal 29 jaar");
        }
        super.setGeboortejaar(geboortejaar);
    }

    public int leeftijdVolgensMens() {
        final int GRENS = 5;
        int leeftijdVolgensMens = 0;
        int leeftijdDier = leeftijd();
        int getal = 10;
        for (int i = 1; i <= leeftijdDier && i <= GRENS; i++) {
            leeftijdVolgensMens += (getal--);
        }

        if (leeftijdDier > GRENS) {
            leeftijdVolgensMens += ((leeftijdDier - GRENS) * GRENS);
        }
        return leeftijdVolgensMens;
    }

    @Override
    public String toString() {
        return String.format("%s, naam is %s",
                super.toString(), naam);
    }

}
