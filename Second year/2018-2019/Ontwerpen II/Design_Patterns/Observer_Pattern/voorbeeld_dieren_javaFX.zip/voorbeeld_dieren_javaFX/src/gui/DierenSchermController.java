package gui;

import domein.DierSoort;
import domein.DierenVerzameling;
import java.io.IOException;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class DierenSchermController extends GridPane {

    @FXML
    private TextArea txaItemOverzicht;

    private KnoppenPaneelController knoppenPaneel;

    private DierenVerzameling domeinController;

    public DierenSchermController(DierenVerzameling dierenVerzameling) {

        this.domeinController = dierenVerzameling;

        //OPLOSSING 1TI: KnoppenPaneel kent DierenScherm
        //(verbetering Ontwerpen II)
        knoppenPaneel = new KnoppenPaneelController(this);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("DierenScherm.fxml"));
        loader.setRoot(this);
        loader.setController(this);
        try {
            loader.load();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        txaItemOverzicht.setText(domeinController.toonOverzicht());

        this.add(knoppenPaneel, 0, 1);
    }

    protected void startDierToevoegenScherm(DierSoort soort) {
        Stage stage = new Stage();
        stage.setTitle(soort.equals(DierSoort.KAT) ? "Kat toevoegen" : "Hond toevoegen");

        Scene scene = new Scene(new DierToevoegenSchermController(domeinController, soort));
        stage.setScene(scene);

        this.setDisable(true);

        //Het hoofdvenster mag niet afgesloten worden
        /*
         In that case we can use the consume() function of the WindowEvent. 
         This will consume the event and prevent the window from closing.
         ------------------------------------------------------------------ */
        Stage stageDierenScherm = (Stage) txaItemOverzicht.getScene().getWindow();
        EventHandler handler = event -> event.consume();
        stageDierenScherm.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, handler);

        //het subvenster mag niet gesloten  worden
        //----------------------------------------        
        stage.setOnCloseRequest(handler);

        //luisteraar indien het subscherm gesloten wordt. 
        //---------------------------------------------
        stage.addEventHandler(WindowEvent.WINDOW_HIDING,
                event -> {
                    DierenSchermController.this.setDisable(false);
                    txaItemOverzicht.setText(domeinController.toonOverzicht());
                    stageDierenScherm.removeEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, handler);
                });

        // Het subscherm wordt niet kleiner dan het minimum scherm.
        //---------------------------------------------------------
        stage.setOnShown(e -> {
            stage.setMinWidth(stage.getWidth());
            stage.setMinHeight(stage.getHeight());
        });

        stage.show();

    }
}
