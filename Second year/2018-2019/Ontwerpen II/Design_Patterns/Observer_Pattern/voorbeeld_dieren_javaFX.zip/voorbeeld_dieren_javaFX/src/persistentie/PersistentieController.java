package persistentie;

import domein.Dier;
import java.util.List;

public class PersistentieController {
    
    private DierenMapper dierenMapper;
    
    public List<Dier> geefDieren()
    {
        if (dierenMapper == null)
            dierenMapper = new DierenMapper();
        return dierenMapper.geefDieren();
    }
    
}
