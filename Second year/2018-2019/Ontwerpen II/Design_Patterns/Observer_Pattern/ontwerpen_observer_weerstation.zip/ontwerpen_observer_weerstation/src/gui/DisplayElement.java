package gui;

public interface DisplayElement {

    public void display();
}
