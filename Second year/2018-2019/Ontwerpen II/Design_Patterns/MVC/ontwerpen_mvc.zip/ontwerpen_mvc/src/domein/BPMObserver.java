package domein;

public interface BPMObserver {

    void updateBPM();
}
