package domein;

public interface BeatObserver {

    void updateBeat();
}
