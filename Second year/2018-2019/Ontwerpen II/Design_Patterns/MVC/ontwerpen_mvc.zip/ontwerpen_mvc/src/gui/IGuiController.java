package gui;

public interface IGuiController {

    public void start();

    public void stop();
}
