
import domein.Bediende;
import domein.Manager;
import domein.Werknemer;

public class StartUp {

    public static void main(String... args) {
        Werknemer werknemerJan = new Bediende("Wolfs", "Jan", "3/5/1980", 2000.00);

        System.out.println(werknemerJan.getJaarInkomst());
        
        // promotie: 
        werknemerJan = new Manager("Wolfs", "Jan", "3/5/1980", 3000.00, 500.50);
        System.out.println(werknemerJan.getJaarInkomst());
    }
}
