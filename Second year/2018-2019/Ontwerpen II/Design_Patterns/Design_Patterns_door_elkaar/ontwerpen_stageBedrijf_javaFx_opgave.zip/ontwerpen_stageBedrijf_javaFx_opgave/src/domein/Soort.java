package domein;

public enum Soort {

    STAGE, BEDRIJF;
}
