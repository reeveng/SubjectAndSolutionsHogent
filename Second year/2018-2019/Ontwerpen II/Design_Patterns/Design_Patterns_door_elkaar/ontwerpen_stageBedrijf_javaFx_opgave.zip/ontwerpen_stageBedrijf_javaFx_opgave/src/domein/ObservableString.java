package domein;

public class ObservableString 

{
    private String theString;
    private final Soort soort;

    public ObservableString(Soort soort) {
        theString = "";
        this.soort = soort;
    }

    public String getTheString() {
        return theString;
    }

    public void setTheString(String theString) {
        this.theString = theString;
    }
}
